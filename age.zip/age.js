var year=prompt("请输入您的出生年份");
var month=prompt("请输入您的出生月份");
var day=prompt("请输入您的出生日日期");
year=parseInt(year);
month=parseInt(month);
day=parseInt(day);

function leapYear(year,month,day){
	var sum,a=31,b=30,c=28,d=29,e;
	if(year % (year % 100 ? 4 : 400)==0){
		switch(month){
			case 1:
            sum=day
            break;
            case 2:
            sum=a+day
            break;
            case 3:
            sum=a+d+day
            break;
            case 4:
            sum=a+d+a+day
            break;
            case 5:
            sum=a+d+a+b+day
            break;
            case 6:
            sum=a+d+a+b+a+day
            break;
            case 7:
            sum=a+d+a+b+a+b+day
            break;
            case 8:
            sum=a+d+a+b+a+b+a+day
            break;
            case 9:
            sum=a+d+a+b+a+b+a+a+day
            break;
            case 10:
            sum=a+d+a+b+a+b+a+a+b+day
            break;
            case 11:
            sum=a+d+a+b+a+b+a+a+b+a+day
            break;
            case 12:
            sum=a+d+a+b+a+b+a+a+b+a+b+day
            break;
		}
	}
	else{   d=28;
			switch(month){
			case 1:
            sum=day
            break;
            case 2:
            sum=a+day
            break;
            case 3:
            sum=a+d+day
            break;
            case 4:
            sum=a+d+a+day
            break;
            case 5:
            sum=a+d+a+b+day
            break;
            case 6:
            sum=a+d+a+b+a+day
            break;
            case 7:
            sum=a+d+a+b+a+b+day
            break;
            case 8:
            sum=a+d+a+b+a+b+a+day
            break;
            case 9:
            sum=a+d+a+b+a+b+a+a+day
            break;
            case 10:
            sum=a+d+a+b+a+b+a+a+b+day
            break;
            case 11:
            sum=a+d+a+b+a+b+a+a+b+a+day
            break;
            case 12:
            sum=a+d+a+b+a+b+a+a+b+a+b+day
            break;
		}

	}
	return sum;
}
e=leapYear(year,month,day);
document.write("您的生日在"+year+"年是第"+e+"天");
